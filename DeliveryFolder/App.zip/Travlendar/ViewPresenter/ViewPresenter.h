//
//  ViewPresenter.h
//  ViewPresenter
//
//  Created by Giovanni Filaferro on 28/12/2017.
//  Copyright © 2017 Giovanni Filaferro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Utilities/Utilities.h>

//! Project version number for ViewPresenter.
FOUNDATION_EXPORT double ViewPresenterVersionNumber;

//! Project version string for ViewPresenter.
FOUNDATION_EXPORT const unsigned char ViewPresenterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ViewPresenter/PublicHeader.h>


