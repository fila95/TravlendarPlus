//
//  Utilities.h
//  Utilities
//
//  Created by Giovanni Filaferro on 28/12/2017.
//  Copyright © 2017 Giovanni Filaferro. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Utilities.
FOUNDATION_EXPORT double UtilitiesVersionNumber;

//! Project version string for Utilities.
FOUNDATION_EXPORT const unsigned char UtilitiesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Utilities/PublicHeader.h>


